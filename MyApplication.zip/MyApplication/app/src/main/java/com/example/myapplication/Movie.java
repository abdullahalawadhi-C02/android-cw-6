package com.example.myapplication;

public class Movie {
    String title;
     String mainActor;
  private   String movieRate;
  private   String  p9rate;
   private String genre;

    public Movie(String title, String mainActor, String movieRate, String p9rate, String genre) {
        this.title = title;
        this.mainActor = mainActor;
        this.movieRate = movieRate;
        this.p9rate = p9rate;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMainActor() {
        return mainActor;
    }

    public void setMainActor(String mainActor) {
        this.mainActor = mainActor;
    }

    public String getMovieRate() {
        return movieRate;
    }

    public void setMovieRate(String movieRate) {
        this.movieRate = movieRate;
    }

    public String getP9rate() {
        return p9rate;
    }

    public void setP9rate(String p9rate) {
        this.p9rate = p9rate;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
}
